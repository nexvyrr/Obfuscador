namespace ObfuscadorKriph.Obfuscator.Encryption
{
	public class VMIntegrityCheck
	{
			
	}
}