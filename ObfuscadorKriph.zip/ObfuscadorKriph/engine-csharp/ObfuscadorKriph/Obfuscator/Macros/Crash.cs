namespace ObfuscadorKriph.Obfuscator.Macros
{
	public class Crash
	{
		
	}
}