namespace ObfuscadorKriph.Obfuscator.Macros
{
    public class StrEncrypt
    {
        
    }
}