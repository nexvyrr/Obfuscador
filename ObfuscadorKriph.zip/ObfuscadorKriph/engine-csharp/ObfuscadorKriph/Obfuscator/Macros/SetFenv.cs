namespace ObfuscadorKriph.Obfuscator.Macros
{
	public class SetFenv
	{
		
	}
}