namespace ObfuscadorKriph.Obfuscator
{
	public class CustomInstructionData
	{
		public VOpcode Opcode;
		public VOpcode WrittenOpcode;
	}
}