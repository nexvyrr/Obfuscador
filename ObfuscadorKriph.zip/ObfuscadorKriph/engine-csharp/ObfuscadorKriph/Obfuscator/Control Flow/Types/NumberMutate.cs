using ObfuscadorKriph.Bytecode_Library.IR;

namespace ObfuscadorKriph.Obfuscator.Control_Flow.Types
{
    public static class NumberMutate
    {
        public static void DoInstructions(Chunk chunk)
        {
            
        }
    }
}