# The Obfuscador Kriph

Ofuscador de Lua 5.1 (bytecode) orientado a Roblox. Compila el script a bytecode,
lo reestructura y genera una VM que lo interpreta en runtime, con flujo de control
falso, cifrado de constantes y mutación de opcodes.

## Estructura

- `engine-js/obfuscador-kriph/`: implementación JavaScript/Node.js.
- `engine-csharp/ObfuscadorKriph/`: implementación C# original y su CLI.
- `run-js.bat` / `run-js.sh`: lanzadores para la implementación Node.js.

## Ejecutar la versión JavaScript

Requisitos: Node.js y un compilador `luac` compatible con Lua 5.1 en PATH. La minificación también puede necesitar Lua instalado.

Windows:
1. Instala Node.js y Lua 5.1/luac.
2. Arrastra un archivo `.lua` sobre `run-js.bat`, o ejecuta desde una terminal:
   `node engine-js/obfuscador-kriph/run.js entrada.lua salida.lua`

Linux/macOS:
1. Instala Node.js y Lua 5.1/luac.
2. Ejecuta:
   `chmod +x run-js.sh`
   `./run-js.sh entrada.lua salida.lua`

Opciones del CLI JS: `--no-control-flow`, `--no-mutate`, `--no-super-ops`,
`--no-compress`, `--no-minify`, `--encrypt-strings`, `--preserve-lines`.

## Implementación C#

`engine-csharp/ObfuscadorKriph/ObfuscadorKriph.csproj` es el proyecto de biblioteca
y `engine-csharp/ObfuscadorKriph CLI/` contiene el proyecto CLI. El código original
apunta a .NET Core 2.2 y herramientas externas `luac`/`luajit`; esa versión de .NET
está obsoleta, por lo que puede requerir ajustes para compilar en entornos actuales.

## Procedencia y licencia (leer antes de redistribuir)

Esta base es un rebranding de un motor de ofuscación Lua de código abierto
conocido en la comunidad de Roblox como "IronBrew2".

- **Motor C# (`engine-csharp/`)**: verificado contra el repo original
  (github.com/Trollicus/ironbrew-2) — es **MIT License, Copyright (c) 2019
  DefCon42**. El texto exacto está en `engine-csharp/LICENSE`. MIT permite
  modificar, rebrandear y redistribuir (incluso vender) libremente, con una
  única condición: mantener ese aviso de copyright incluido en las copias.
  Está cumplido en este paquete.
- **Motor JS (`engine-js/`)**: edición originalmente watermarked como
  "LightWyn Project" (autor `@it_kuridev`). No encontré una licencia pública
  confirmada para esta parte. El linaje general de este motor (incluyendo
  variantes históricamente comercializadas bajo el nombre "MoonSec") tiene
  reputación de herramienta de pago/acceso restringido en comunidades de
  reversing, así que no asumas que está igual de libre que el motor C#.
  Si vas a publicar el repo en público, lo más seguro es dejar esta parte
  afuera o mantenerla privada hasta confirmar su licencia real.
