@echo off
if "%~1"=="" (
  echo Uso: arrastra un archivo .lua sobre este archivo o ejecuta run-js.bat entrada.lua [salida.lua]
  pause
  exit /b 1
)
node "%~dp0engine-js\obfuscador-kriph\run.js" "%~1" "%~2"
pause
