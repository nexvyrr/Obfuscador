#!/usr/bin/env sh
set -eu
if [ "$#" -lt 1 ]; then
  echo "Uso: ./run-js.sh entrada.lua [salida.lua]"
  exit 1
fi
node "$(dirname "$0")/engine-js/obfuscador-kriph/run.js" "$@"
